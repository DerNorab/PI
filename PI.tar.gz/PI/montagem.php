<html>
<meta charset="UTF-8"/>
    <head>
        <title>Montagem de PC e Dicas em Hardwares</title>
        <link rel="shortcut icon" href="imagens/logo1.png" type="image/x-icon" />
        </head>
<link rel="stylesheet" href="estilos.css"></link>
    <body>
        <center><img src="imagens/logo1.png" height="200px" alt="Logo"/></center>
        <div class="menu">
           <nav>
        <li><a href="proposta.html">Proposta do Site</a></li>
        <li><a href="dicas.html">Dicas em Hardwares</a></li>
        <li><a href="montagem.html">Montagem do PC</a></li>
        <li><a href="quemsomos.html">Quem Somos</a></li>
    </nav>
       </div>
        <div class="fundo_1">
            <div class="h1_a">
                <h1>Montagem de PC</h1></div>
                <div class="p_a"><p>Esta página terá um formulário abaixo contendo algumas perguntas com base na sua necessidade para uso pessoal.
                    No final do formulário você será redirecionado para uma página com alguns computadores prontos com base nas suas perguntas e necessidades.</p>
            </div></div>
        </br></br>
        <form method="post" action="montagem2.php">
        <div class="fundo_1">
            <div class="h1_a">
            <h2>Montagem do Computador</h2>
            <p>Insira seu Nome</p>
            <input type="text" size="20" name="nome"></br>

            <h2>Primeira Pergunta</h2>
            <p>Qual o ser orçamento?</p>
            <input type="text" size="20" name="resposta1"></br>

            <h2>Segunda Pergunta</h2>
            <p>O seu uso é para Pessoal?</p>
            <input type="text" size="20" name="resposta2"></br>

            <h2>Terceira Pergunta</h2>
            <p>O seu uso é para Trabalho?</p>
            <input type="text" size="20" name="resposta3"></br>

            <h2>Quarta Pergunta</h2>
            <p>O seu uso é para Games?</p>
            <input type="text" size="20" name="resposta4"></br>
            
            <p><input type="submit" value="Enviar formulário" name="enviar"></p></br>
        </form>
        </div></div>
    </body>
</html>